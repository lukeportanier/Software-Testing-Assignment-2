package AlertLimit;

import AlertLimit.enums.AlertLimitOperatorStates;
import WebsiteNavigation.WebsiteOperator;
import nz.ac.waikato.modeljunit.Action;
import nz.ac.waikato.modeljunit.FsmModel;
import nz.ac.waikato.modeljunit.GreedyTester;
import nz.ac.waikato.modeljunit.StopOnFailureListener;
import nz.ac.waikato.modeljunit.coverage.ActionCoverage;
import nz.ac.waikato.modeljunit.coverage.StateCoverage;
import nz.ac.waikato.modeljunit.coverage.TransitionPairCoverage;
import org.junit.Assert;
import org.junit.Test;

import java.util.Random;

public class AlertLimitOperatorModelTest implements FsmModel
{
    //Linking the SUT
    private AlertLimitOperator systemUnderTest = new AlertLimitOperator();

    //State Variables
    private AlertLimitOperatorStates modelAlertLimit = AlertLimitOperatorStates.IDLE;
    private int numAlerts = 0;

    //Method implementations
    @Override
    public AlertLimitOperatorStates getState() {
        return modelAlertLimit;
    }

    @Override
    public void reset(final boolean var1) {
        if (var1) {
            systemUnderTest = new AlertLimitOperator();
        }
        modelAlertLimit = AlertLimitOperatorStates.IDLE;
        numAlerts = 0;
    }

    //Transitions incl. guards
    public boolean CreateAlertGuard() {
        return getState().equals(AlertLimitOperatorStates.IDLE);
    }
    public @Action void CreateAlert() {
        //Updating SUT
        systemUnderTest.CreateAlert();

        //Updating model
        if(numAlerts<5)
        {
            modelAlertLimit = AlertLimitOperatorStates.IDLE;
            numAlerts++;
        }else{
            modelAlertLimit = AlertLimitOperatorStates.MAX_ALERTS;
        }

        Assert.assertTrue("System has More than 5 alerts",systemUnderTest.hasLessThan5Alerts());
        Assert.assertEquals(numAlerts, systemUnderTest.numAlerts);

    }

    public boolean DeleteAlertsGuard() {
        return getState().equals(AlertLimitOperatorStates.IDLE) || getState().equals(AlertLimitOperatorStates.MAX_ALERTS);
    }
    public @Action void DeleteAlerts()
    {
        //Updating SUt
        systemUnderTest.DeleteAlerts();

        //Updating Model
        modelAlertLimit = AlertLimitOperatorStates.IDLE;
        numAlerts = 0;

        //Assertions
        Assert.assertEquals(0, systemUnderTest.getNumAlerts());
    }

    //Test runner
    @Test
    public void AlertLimitOperatorModelRunner() {
        final GreedyTester tester = new GreedyTester(new AlertLimitOperatorModelTest()); //Creates a test generator that can generate random walks. A greedy random walk gives preference to transitions that have never been taken before. Once all transitions out of a state have been taken, it behaves the same as a random walk.
        tester.setRandom(new Random()); //Allows for a random path each time the model is run.
        tester.buildGraph(); //Builds a model of our FSM to ensure that the coverage metrics are correct.
        tester.addListener(new StopOnFailureListener()); //This listener forces the test class to stop running as soon as a failure is encountered in the model.
        tester.addListener("verbose"); //This gives you printed statements of the transitions being performed along with the source and destination states.
        tester.addCoverageMetric(new TransitionPairCoverage()); //Records the transition pair coverage i.e. the number of paired transitions traversed during the execution of the test.
        tester.addCoverageMetric(new StateCoverage()); //Records the state coverage i.e. the number of states which have been visited during the execution of the test.
        tester.addCoverageMetric(new ActionCoverage()); //Records the number of @Action methods which have ben executed during the execution of the test.
        tester.generate(500); //Generates 500 transitions
        tester.printCoverage(); //Prints the coverage metrics specified above.
    }

}
