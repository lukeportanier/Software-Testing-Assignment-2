package AlertLimit.enums;

public enum AlertLimitOperatorStates
{

    IDLE,
    MAX_ALERTS;
}
