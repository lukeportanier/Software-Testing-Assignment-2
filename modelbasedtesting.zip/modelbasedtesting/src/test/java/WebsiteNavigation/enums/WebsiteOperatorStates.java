package WebsiteNavigation.enums;

public enum WebsiteOperatorStates
{
    HOME,
    LOGIN,
    ALERTS;
}
