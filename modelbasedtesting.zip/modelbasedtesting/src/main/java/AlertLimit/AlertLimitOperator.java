package AlertLimit;

public class AlertLimitOperator
{
    int numAlerts = 0;

    Boolean CreateAlert()
    {
        if(numAlerts<5)
        {
            numAlerts++;
            return true;
        }else if(numAlerts>=5){
            return false;
        }else{
            throw new IllegalStateException();
        }
    }

    Boolean DeleteAlerts()
    {
        numAlerts = 0;
        return true;
    }

    Boolean hasLessThan5Alerts()
    {
        if(numAlerts<=5)
            return true;
        else
            return false;
    }

    int getNumAlerts()
    {
        return numAlerts;
    }
}
