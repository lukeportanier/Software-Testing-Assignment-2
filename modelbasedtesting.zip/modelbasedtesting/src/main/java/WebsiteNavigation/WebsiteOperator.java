package WebsiteNavigation;

public class WebsiteOperator
{

    private boolean loggedIn = false;

    Boolean LoginPressed()
    {
        if(!loggedIn)
            return true;
        else
            throw new IllegalStateException();
    }

    Boolean ValidLogIn()
    {
        if(!loggedIn)
        {
            loggedIn = true;
            return true;
        }else{
            throw new IllegalStateException();
        }
    }

    Boolean Logout()
    {
        if(loggedIn)
        {
            loggedIn = false;
            return true;
        }else{
            throw new IllegalStateException();
        }
    }

    Boolean AlertsViewed()
    {
        if(loggedIn)
            return true;
        else
            return false;
    }

    Boolean isLoggedIn()
    {
        return loggedIn;
    }

}
