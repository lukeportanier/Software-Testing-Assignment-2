
package larva;

public interface _callable {

public void _call(String _info, int... _event);

public void _call_all_filtered(String _info, int... _event);
}