package larva;


import java.util.LinkedHashMap;
import java.io.PrintWriter;

public class _cls_larva0 implements _callable{

public static PrintWriter pw; 
public static _cls_larva0 root;

public static LinkedHashMap<_cls_larva0,_cls_larva0> _cls_larva0_instances = new LinkedHashMap<_cls_larva0,_cls_larva0>();
static{
try{
RunningClock.start();
pw = new PrintWriter("C:\\Users\\lukep\\workspace\\Assignment 2 - Software Testing/src/output_larva.txt");

root = new _cls_larva0();
_cls_larva0_instances.put(root, root);
  root.initialisation();
}catch(Exception ex)
{ex.printStackTrace();}
}

_cls_larva0 parent; //to remain null - this class does not have a parent!
int no_automata = 2;
 public int numAlerts =0 ;
 public boolean loggedIn =false ;

public static void initialize(){}
//inheritance could not be used because of the automatic call to super()
//when the constructor is called...we need to keep the SAME parent if this exists!

public _cls_larva0() {
}

public void initialisation() {
}

public static _cls_larva0 _get_cls_larva0_inst() { synchronized(_cls_larva0_instances){
 return root;
}
}

public boolean equals(Object o) {
 if ((o instanceof _cls_larva0))
{return true;}
else
{return false;}
}

public int hashCode() {
return 0;
}

public void _call(String _info, int... _event){
synchronized(_cls_larva0_instances){
_performLogic_AlertLimitProperty(_info, _event);
_performLogic_SiteNavigation(_info, _event);
}
}

public void _call_all_filtered(String _info, int... _event){
}

public static void _call_all(String _info, int... _event){

_cls_larva0[] a = new _cls_larva0[1];
synchronized(_cls_larva0_instances){
a = _cls_larva0_instances.keySet().toArray(a);}
for (_cls_larva0 _inst : a)

if (_inst != null) _inst._call(_info, _event);
}

public void _killThis(){
try{
if (--no_automata == 0){
synchronized(_cls_larva0_instances){
_cls_larva0_instances.remove(this);}
}
else if (no_automata < 0)
{throw new Exception("no_automata < 0!!");}
}catch(Exception ex){ex.printStackTrace();}
}

int _state_id_AlertLimitProperty = 1;

public void _performLogic_AlertLimitProperty(String _info, int... _event) {

_cls_larva0.pw.println("[AlertLimitProperty]AUTOMATON::> AlertLimitProperty("+") STATE::>"+ _string_AlertLimitProperty(_state_id_AlertLimitProperty, 0));
_cls_larva0.pw.flush();

if (0==1){}
else if (_state_id_AlertLimitProperty==1){
		if (1==0){}
		else if ((_occurredEvent(_event,0/*alertCreated*/)) && (numAlerts ==5 )){
		++numAlerts ;
_cls_larva0.pw .println ("Alart Limit Exceeded! Num Alerts: "+numAlerts );

		_state_id_AlertLimitProperty = 0;//moving to state extraalerts
		_goto_AlertLimitProperty(_info);
		}
		else if ((_occurredEvent(_event,0/*alertCreated*/))){
		numAlerts ++;
_cls_larva0.pw .println ("Alert Created, Num of Alerts: "+numAlerts );

		_state_id_AlertLimitProperty = 1;//moving to state idle
		_goto_AlertLimitProperty(_info);
		}
		else if ((_occurredEvent(_event,2/*alertsDeleted*/))){
		numAlerts =0 ;
_cls_larva0.pw .println ("Alerts Deleted, Num of Alerts: "+numAlerts );

		_state_id_AlertLimitProperty = 1;//moving to state idle
		_goto_AlertLimitProperty(_info);
		}
}
}

public void _goto_AlertLimitProperty(String _info){
_cls_larva0.pw.println("[AlertLimitProperty]MOVED ON METHODCALL: "+ _info +" TO STATE::> " + _string_AlertLimitProperty(_state_id_AlertLimitProperty, 1));
_cls_larva0.pw.flush();
}

public String _string_AlertLimitProperty(int _state_id, int _mode){
switch(_state_id){
case 0: if (_mode == 0) return "extraalerts"; else return "!!!SYSTEM REACHED BAD STATE!!! extraalerts "+new _BadStateExceptionlarva().toString()+" ";
case 1: if (_mode == 0) return "idle"; else return "idle";
default: return "!!!SYSTEM REACHED AN UNKNOWN STATE!!!";
}
}
int _state_id_SiteNavigation = 5;

public void _performLogic_SiteNavigation(String _info, int... _event) {

_cls_larva0.pw.println("[SiteNavigation]AUTOMATON::> SiteNavigation("+") STATE::>"+ _string_SiteNavigation(_state_id_SiteNavigation, 0));
_cls_larva0.pw.flush();

if (0==1){}
else if (_state_id_SiteNavigation==3){
		if (1==0){}
		else if ((_occurredEvent(_event,4/*alertsViewed*/)) && (loggedIn ==false )){
		_cls_larva0.pw .println ("Viewed Alerts without being logged in!");

		_state_id_SiteNavigation = 2;//moving to state noaccess
		_goto_SiteNavigation(_info);
		}
		else if ((_occurredEvent(_event,4/*alertsViewed*/)) && (loggedIn ==true )){
		_cls_larva0.pw .println ("Re-Entered Alerts");

		_state_id_SiteNavigation = 3;//moving to state alerts
		_goto_SiteNavigation(_info);
		}
		else if ((_occurredEvent(_event,8/*loggedOut*/))){
		loggedIn =false ;
_cls_larva0.pw .println ("Logged Out Moved to Home");

		_state_id_SiteNavigation = 5;//moving to state home
		_goto_SiteNavigation(_info);
		}
}
else if (_state_id_SiteNavigation==5){
		if (1==0){}
		else if ((_occurredEvent(_event,6/*validLogin*/))){
		loggedIn =true ;
_cls_larva0.pw .println ("Moved to Alerts on Valid Login: "+loggedIn );

		_state_id_SiteNavigation = 3;//moving to state alerts
		_goto_SiteNavigation(_info);
		}
		else if ((_occurredEvent(_event,4/*alertsViewed*/)) && (loggedIn ==false )){
		_cls_larva0.pw .println ("Alerts Viewed without being logged in!");

		_state_id_SiteNavigation = 2;//moving to state noaccess
		_goto_SiteNavigation(_info);
		}
}
}

public void _goto_SiteNavigation(String _info){
_cls_larva0.pw.println("[SiteNavigation]MOVED ON METHODCALL: "+ _info +" TO STATE::> " + _string_SiteNavigation(_state_id_SiteNavigation, 1));
_cls_larva0.pw.flush();
}

public String _string_SiteNavigation(int _state_id, int _mode){
switch(_state_id){
case 3: if (_mode == 0) return "alerts"; else return "alerts";
case 2: if (_mode == 0) return "noaccess"; else return "!!!SYSTEM REACHED BAD STATE!!! noaccess "+new _BadStateExceptionlarva().toString()+" ";
case 4: if (_mode == 0) return "login"; else return "login";
case 5: if (_mode == 0) return "home"; else return "home";
default: return "!!!SYSTEM REACHED AN UNKNOWN STATE!!!";
}
}

public boolean _occurredEvent(int[] _events, int event){
for (int i:_events) if (i == event) return true;
return false;
}
}