package main;

import java.util.Date;

import org.json.JSONObject;

public class Event {
	
	private String id;
	private String timestamp;
	private int eventLogType;
	private String userId;
	
	private SystemState systemState;
	
	public Event (String id, String timestamp,int eventLogType, String userId, SystemState systemState)
	{
		this.eventLogType = eventLogType;
		this.id = id;
		this.timestamp = timestamp;
		this.userId = userId;
		this.systemState = systemState;
	}

	public String toString()
	{
		return "Event Log Type: "+eventLogType+" Id: "+id+" TimeStamp: "+timestamp+" User Id: "+userId+"\n"
				+systemState.toString();
	}
	
	public String getId() {
		return id;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public int getEventLogType() {
		return eventLogType;
	}

	public String getUserId() {
		return userId;
	}

	public SystemState getSystemState() {
		return systemState;
	}

}
