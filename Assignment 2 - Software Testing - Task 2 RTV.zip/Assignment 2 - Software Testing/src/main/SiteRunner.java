package main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import org.json.*;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class SiteRunner 
{
	private static final String USER_ID = "ecad9caf-420a-4990-b451-3a73c9a134f6";
	private static final String GET_URL = "https://api.marketalertum.com/EventsLog/"+USER_ID;
	private static ArrayList<Event> events = new ArrayList<Event>();
	private static int numAlerts = 0;
	
	private static String timestamp = "";
	
	public static void AlertCreated()
	{
		System.out.println("Alert Created at: "+timestamp);
	}
	
	public static void AlertsDeleted()
	{
		System.out.println("Alerts Deleted at: "+timestamp);
	}
	
	public static void UserViewedAlerts()
	{
		System.out.println("Alerts Viewed at: "+timestamp);
	}
	
	public static void UserValidLogin()
	{
		System.out.println("User Logged in at: "+timestamp);
	}
	
	public static void UserLoggedOut()
	{
		System.out.println("User Logged out at: "+timestamp);
	}
	
	public static void InvalidLogin()
	{
		System.out.println("Invalid Login at: "+timestamp);
	}
	
	/*
	Online API Caller is used to test API calls this is done to make it simple to follow calls rather than generating random number of posts/deletes
	Following site was found: https://reqbin.com/
	For Deletes->
		Request: https://api.marketalertum.com/Alert?userId=ecad9caf-420a-4990-b451-3a73c9a134f6
	For Posts->
	Request: https://api.marketalertum.com/Alert
	Body Example:
	{
		"alertType": 6,
		"heading": "Jumper Windows 11 Laptop",
		"description": "Jumper Windows 11 Laptop 1080P Display,12GB RAM 256GB SSD",
		"url": "https://www.amazon.co.uk/Windows-Display-Ultrabook-Processor-Bluetooth",
		"imageUrl" : "https://m.media-amazon.com/images/I/712Xf2LtbJL._AC_SX679_.jpg",
		"postedBy": "ecad9caf-420a-4990-b451-3a73c9a134f6",
		"priceInCents": 24999
	 }
	 */
	
	public static void Run() throws IOException, JSONException, ParseException, InterruptedException
	{		

		while(true)
		{
			GetRequest();
			
			for(int i=0;i<events.size();i++)
			{
				int eventType = events.get(i).getEventLogType();
				timestamp = events.get(i).getTimestamp();
				numAlerts = events.get(i).getSystemState().getAlerts().length();

				//Event 0: Alert Created
				switch(eventType)
				{
					//Alert Created
					case 0:
						AlertCreated();
						break;
					//Alerts Deleted
					case 1:
						AlertsDeleted();
						break;
					//User Valid Login
					case 5:
						UserValidLogin();
						break;
					//User Logged Out
					case 6:
						UserLoggedOut();
						break;
					//User Viewed Alerts
					case 7:
						UserViewedAlerts();
						break;
				}
			}
			
		}
		
	}
	
	public static void main (String[] args) throws IOException, JSONException, ParseException, InterruptedException
	{
		Run();
	}
	
	public int getNumALerts()
	{
		return numAlerts;
	}
	
	public static void DeleteRequest() throws IOException
	{
		URL url = new URL("https://api.marketalertum.com/Alert?userId=ecad9caf-420a-4990-b451-3a73c9a134f6");
        HttpURLConnection http = (HttpURLConnection)url.openConnection();
        http.setRequestMethod("DELETE");

        http.disconnect();
	}
	
	public static void PostRequest(String alertJsonString) throws IOException
	{
		URL url = new URL("https://api.marketalertum.com/Alert");
        HttpURLConnection http = (HttpURLConnection)url.openConnection();
        http.setRequestMethod("POST");
        http.setDoOutput(true);
        http.setRequestProperty("Accept", "application/json");
        http.setRequestProperty("Content-Type", "application/json");

        byte[] out = alertJsonString.getBytes(StandardCharsets.UTF_8);

        OutputStream stream = http.getOutputStream();
        stream.write(out);
        
        System.out.println("Respose: "+http.getResponseCode());
        
        http.disconnect();
	}
	
	public static void GetRequest() throws IOException, JSONException, ParseException
	{
		events.clear();
		URL obj = new URL(GET_URL);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		con.setRequestMethod("GET");
		int responseCode = con.getResponseCode();

		if (responseCode == HttpURLConnection.HTTP_OK) { // success
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();
			
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
		
			JSONArray jsnArray = new JSONArray(response.toString());

			for(int i=0; i<jsnArray.length();i++)
			{
				JSONObject jsnObject = jsnArray.getJSONObject(i);
				
				//Event Data
				String id = jsnObject.getString("id");
				int eventLogType = jsnObject.getInt("eventLogType");
				String timestamp = jsnObject.getString("timestamp");
				String userId = jsnObject.getString("userId");
				
				//System State Data
				JSONObject systemStateObj = jsnObject.getJSONObject("systemState");
				
				String systemStateUserId = systemStateObj.getString("userId");
				boolean loggedIn = systemStateObj.getBoolean("loggedIn");
				JSONArray alerts = systemStateObj.getJSONArray("alerts");
				
				events.add(new Event(id, timestamp, eventLogType, userId, new SystemState(systemStateUserId, loggedIn, alerts)));
				
			}
			
		} else {
			System.out.println("GET request did not work.");
		}
	}
}


