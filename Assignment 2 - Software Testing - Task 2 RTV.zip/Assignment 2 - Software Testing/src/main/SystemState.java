package main;

import java.util.ArrayList;

import org.json.JSONArray;

public class SystemState 
{
	private String userId;
	private boolean loggedIn;
	private JSONArray alerts;
	
	public SystemState(String userId, boolean loggedIn, JSONArray alerts)
	{
		this.userId = userId;
		this.loggedIn = loggedIn;
		this.alerts = alerts;
	}
	
	public String toString()
	{
		return "User Id: "+userId+" LoggedIn: "+loggedIn+" alerts: "+alerts.toString();
	}

	public String getUserId() {
		return userId;
	}

	public boolean isLoggedIn() {
		return loggedIn;
	}

	public JSONArray getAlerts() {
		return alerts;
	}
	
}
